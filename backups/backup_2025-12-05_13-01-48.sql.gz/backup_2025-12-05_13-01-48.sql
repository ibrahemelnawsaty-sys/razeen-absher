-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: absher
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` VALUES ('absher-cache-emergency_services','a:10:{i:0;a:14:{s:2:\"id\";i:1;s:4:\"name\";s:45:\"مستشفى الملك فهد الجامعي\";s:7:\"name_en\";s:29:\"King Fahd University Hospital\";s:4:\"type\";s:8:\"hospital\";s:7:\"address\";s:71:\"طريق الملك فهد، حي الياسمين، الرياض 11564\";s:5:\"phone\";s:9:\"920012345\";s:15:\"emergency_phone\";s:3:\"997\";s:3:\"lat\";d:24.7236;s:3:\"lng\";d:46.6853;s:7:\"is_open\";b:1;s:13:\"working_hours\";s:11:\"24 ساعة\";s:11:\"specialties\";a:4:{i:0;s:10:\"طوارئ\";i:1;s:10:\"جراحة\";i:2;s:12:\"باطنية\";i:3;s:10:\"أطفال\";}s:10:\"beds_count\";i:520;s:6:\"rating\";d:4.5;}i:1;a:14:{s:2:\"id\";i:2;s:4:\"name\";s:47:\"مستشفى الملك خالد الجامعي\";s:7:\"name_en\";s:31:\"King Khalid University Hospital\";s:4:\"type\";s:8:\"hospital\";s:7:\"address\";s:73:\"طريق الملك عبدالعزيز، حي المربع، الرياض\";s:5:\"phone\";s:9:\"920023456\";s:15:\"emergency_phone\";s:3:\"997\";s:3:\"lat\";d:24.7136;s:3:\"lng\";d:46.6753;s:7:\"is_open\";b:1;s:13:\"working_hours\";s:11:\"24 ساعة\";s:11:\"specialties\";a:4:{i:0;s:10:\"طوارئ\";i:1;s:6:\"قلب\";i:2;s:8:\"عظام\";i:3;s:10:\"أعصاب\";}s:10:\"beds_count\";i:850;s:6:\"rating\";d:4.7;}i:2;a:14:{s:2:\"id\";i:3;s:4:\"name\";s:36:\"مستشفى الحرس الوطني\";s:7:\"name_en\";s:23:\"National Guard Hospital\";s:4:\"type\";s:8:\"hospital\";s:7:\"address\";s:53:\"طريق الملك عبدالعزيز، الرياض\";s:5:\"phone\";s:9:\"920034567\";s:15:\"emergency_phone\";s:3:\"997\";s:3:\"lat\";d:24.745;s:3:\"lng\";d:46.658;s:7:\"is_open\";b:1;s:13:\"working_hours\";s:11:\"24 ساعة\";s:11:\"specialties\";a:3:{i:0;s:10:\"طوارئ\";i:1;s:10:\"جراحة\";i:2;s:21:\"نساء وولادة\";}s:10:\"beds_count\";i:1200;s:6:\"rating\";d:4.8;}i:3;a:13:{s:2:\"id\";i:4;s:4:\"name\";s:38:\"مركز الإسعاف الرئيسي\";s:7:\"name_en\";s:21:\"Main Ambulance Center\";s:4:\"type\";s:9:\"ambulance\";s:7:\"address\";s:56:\"شارع العليا، حي العليا، الرياض\";s:5:\"phone\";s:3:\"997\";s:15:\"emergency_phone\";s:3:\"997\";s:3:\"lat\";d:24.7036;s:3:\"lng\";d:46.6653;s:7:\"is_open\";b:1;s:13:\"working_hours\";s:11:\"24 ساعة\";s:16:\"ambulances_count\";i:25;s:6:\"rating\";d:4.6;}i:4;a:13:{s:2:\"id\";i:5;s:4:\"name\";s:38:\"مركز الإسعاف الشمالي\";s:7:\"name_en\";s:22:\"North Ambulance Center\";s:4:\"type\";s:9:\"ambulance\";s:7:\"address\";s:53:\"طريق الدائري الشمالي، الرياض\";s:5:\"phone\";s:3:\"997\";s:15:\"emergency_phone\";s:3:\"997\";s:3:\"lat\";d:24.785;s:3:\"lng\";d:46.67;s:7:\"is_open\";b:1;s:13:\"working_hours\";s:11:\"24 ساعة\";s:16:\"ambulances_count\";i:15;s:6:\"rating\";d:4.4;}i:5;a:13:{s:2:\"id\";i:6;s:4:\"name\";s:55:\"الدفاع المدني - المركز الرئيسي\";s:7:\"name_en\";s:27:\"Civil Defense - Main Center\";s:4:\"type\";s:12:\"fire_station\";s:7:\"address\";s:73:\"طريق الملك عبدالعزيز، حي المربع، الرياض\";s:5:\"phone\";s:3:\"998\";s:15:\"emergency_phone\";s:3:\"998\";s:3:\"lat\";d:24.7336;s:3:\"lng\";d:46.6953;s:7:\"is_open\";b:1;s:13:\"working_hours\";s:11:\"24 ساعة\";s:17:\"fire_trucks_count\";i:12;s:6:\"rating\";d:4.9;}i:6;a:13:{s:2:\"id\";i:7;s:4:\"name\";s:49:\"الدفاع المدني - شمال الرياض\";s:7:\"name_en\";s:28:\"Civil Defense - North Riyadh\";s:4:\"type\";s:12:\"fire_station\";s:7:\"address\";s:53:\"طريق الدائري الشمالي، الرياض\";s:5:\"phone\";s:3:\"998\";s:15:\"emergency_phone\";s:3:\"998\";s:3:\"lat\";d:24.78;s:3:\"lng\";d:46.66;s:7:\"is_open\";b:1;s:13:\"working_hours\";s:11:\"24 ساعة\";s:17:\"fire_trucks_count\";i:8;s:6:\"rating\";d:4.7;}i:7;a:13:{s:2:\"id\";i:8;s:4:\"name\";s:30:\"مركز شرطة النخيل\";s:7:\"name_en\";s:25:\"Al Nakheel Police Station\";s:4:\"type\";s:6:\"police\";s:7:\"address\";s:41:\"حي النخيل، شمال الرياض\";s:5:\"phone\";s:3:\"989\";s:15:\"emergency_phone\";s:3:\"911\";s:3:\"lat\";d:24.7436;s:3:\"lng\";d:46.7053;s:7:\"is_open\";b:1;s:13:\"working_hours\";s:11:\"24 ساعة\";s:14:\"officers_count\";i:45;s:6:\"rating\";d:4.5;}i:8;a:13:{s:2:\"id\";i:9;s:4:\"name\";s:30:\"مركز شرطة العليا\";s:7:\"name_en\";s:20:\"Olaya Police Station\";s:4:\"type\";s:6:\"police\";s:7:\"address\";s:36:\"شارع العليا، الرياض\";s:5:\"phone\";s:3:\"989\";s:15:\"emergency_phone\";s:3:\"911\";s:3:\"lat\";d:24.71;s:3:\"lng\";d:46.675;s:7:\"is_open\";b:1;s:13:\"working_hours\";s:11:\"24 ساعة\";s:14:\"officers_count\";i:60;s:6:\"rating\";d:4.6;}i:9;a:13:{s:2:\"id\";i:10;s:4:\"name\";s:32:\"مركز الأمن الشامل\";s:7:\"name_en\";s:29:\"Comprehensive Security Center\";s:4:\"type\";s:6:\"police\";s:7:\"address\";s:41:\"طريق الملك فهد، الرياض\";s:5:\"phone\";s:3:\"911\";s:15:\"emergency_phone\";s:3:\"911\";s:3:\"lat\";d:24.715;s:3:\"lng\";d:46.685;s:7:\"is_open\";b:1;s:13:\"working_hours\";s:11:\"24 ساعة\";s:14:\"officers_count\";i:80;s:6:\"rating\";d:4.8;}}',1764428732),('absher-cache-municipal_projects','a:3:{i:0;a:10:{s:2:\"id\";i:1;s:4:\"name\";s:48:\"مشروع تطوير طريق الملك فهد\";s:4:\"type\";s:4:\"road\";s:8:\"location\";s:57:\"من تقاطع العليا إلى حي الياسمين\";s:6:\"status\";s:11:\"in_progress\";s:10:\"contractor\";s:39:\"شركة بن لادن السعودية\";s:10:\"completion\";i:65;s:9:\"remaining\";s:10:\"4 أشهر\";s:3:\"lat\";d:24.72;s:3:\"lng\";d:46.68;}i:1;a:10:{s:2:\"id\";i:2;s:4:\"name\";s:34:\"إنشاء حديقة الورود\";s:4:\"type\";s:4:\"park\";s:8:\"location\";s:41:\"حي الورود، شمال الرياض\";s:6:\"status\";s:9:\"completed\";s:10:\"contractor\";s:23:\"شركة العمران\";s:10:\"completion\";i:85;s:9:\"remaining\";s:8:\"2 شهر\";s:3:\"lat\";d:24.74;s:3:\"lng\";d:46.7;}i:2;a:10:{s:2:\"id\";i:3;s:4:\"name\";s:34:\"صيانة شبكة الإنارة\";s:4:\"type\";s:8:\"lighting\";s:8:\"location\";s:28:\"طريق الملك خالد\";s:6:\"status\";s:11:\"in_progress\";s:10:\"contractor\";s:46:\"الشركة السعودية للكهرباء\";s:10:\"completion\";i:40;s:9:\"remaining\";s:10:\"6 أشهر\";s:3:\"lat\";d:24.71;s:3:\"lng\";d:46.67;}}',1764428732),('absher-cache-search_24296d0c8bece172352d5dc6f2603ce3','O:28:\"Illuminate\\Http\\JsonResponse\":11:{s:7:\"headers\";O:50:\"Symfony\\Component\\HttpFoundation\\ResponseHeaderBag\":5:{s:10:\"\0*\0headers\";a:3:{s:13:\"cache-control\";a:1:{i:0;s:17:\"no-cache, private\";}s:4:\"date\";a:1:{i:0;s:29:\"Sat, 29 Nov 2025 14:05:32 GMT\";}s:12:\"content-type\";a:1:{i:0;s:16:\"application/json\";}}s:15:\"\0*\0cacheControl\";a:0:{}s:23:\"\0*\0computedCacheControl\";a:2:{s:8:\"no-cache\";b:1;s:7:\"private\";b:1;}s:10:\"\0*\0cookies\";a:0:{}s:14:\"\0*\0headerNames\";a:3:{s:13:\"cache-control\";s:13:\"Cache-Control\";s:4:\"date\";s:4:\"Date\";s:12:\"content-type\";s:12:\"Content-Type\";}}s:10:\"\0*\0content\";s:1145:\"{\"results\":[{\"id\":8,\"name\":\"\\u0645\\u0631\\u0643\\u0632 \\u0634\\u0631\\u0637\\u0629 \\u0627\\u0644\\u0646\\u062e\\u064a\\u0644\",\"type\":\"service\",\"category\":\"police\",\"address\":\"\\u062d\\u064a \\u0627\\u0644\\u0646\\u062e\\u064a\\u0644\\u060c \\u0634\\u0645\\u0627\\u0644 \\u0627\\u0644\\u0631\\u064a\\u0627\\u0636\",\"lat\":24.7436,\"lng\":46.7053,\"icon\":\"\\ud83d\\udc6e\",\"distance\":null},{\"id\":9,\"name\":\"\\u0645\\u0631\\u0643\\u0632 \\u0634\\u0631\\u0637\\u0629 \\u0627\\u0644\\u0639\\u0644\\u064a\\u0627\",\"type\":\"service\",\"category\":\"police\",\"address\":\"\\u0634\\u0627\\u0631\\u0639 \\u0627\\u0644\\u0639\\u0644\\u064a\\u0627\\u060c \\u0627\\u0644\\u0631\\u064a\\u0627\\u0636\",\"lat\":24.71,\"lng\":46.675,\"icon\":\"\\ud83d\\udc6e\",\"distance\":null},{\"id\":1,\"name\":\"\\u0645\\u0634\\u0631\\u0648\\u0639 \\u062a\\u0637\\u0648\\u064a\\u0631 \\u0637\\u0631\\u064a\\u0642 \\u0627\\u0644\\u0645\\u0644\\u0643 \\u0641\\u0647\\u062f\",\"type\":\"project\",\"category\":\"road\",\"address\":\"\\u0645\\u0646 \\u062a\\u0642\\u0627\\u0637\\u0639 \\u0627\\u0644\\u0639\\u0644\\u064a\\u0627 \\u0625\\u0644\\u0649 \\u062d\\u064a \\u0627\\u0644\\u064a\\u0627\\u0633\\u0645\\u064a\\u0646\",\"lat\":24.72,\"lng\":46.68,\"icon\":\"\\ud83d\\udee3\\ufe0f\",\"status\":\"in_progress\"}],\"total\":3,\"query\":\"\\u0634\\u0631\"}\";s:10:\"\0*\0version\";s:3:\"1.0\";s:13:\"\0*\0statusCode\";i:200;s:13:\"\0*\0statusText\";s:2:\"OK\";s:10:\"\0*\0charset\";N;s:7:\"\0*\0data\";s:1145:\"{\"results\":[{\"id\":8,\"name\":\"\\u0645\\u0631\\u0643\\u0632 \\u0634\\u0631\\u0637\\u0629 \\u0627\\u0644\\u0646\\u062e\\u064a\\u0644\",\"type\":\"service\",\"category\":\"police\",\"address\":\"\\u062d\\u064a \\u0627\\u0644\\u0646\\u062e\\u064a\\u0644\\u060c \\u0634\\u0645\\u0627\\u0644 \\u0627\\u0644\\u0631\\u064a\\u0627\\u0636\",\"lat\":24.7436,\"lng\":46.7053,\"icon\":\"\\ud83d\\udc6e\",\"distance\":null},{\"id\":9,\"name\":\"\\u0645\\u0631\\u0643\\u0632 \\u0634\\u0631\\u0637\\u0629 \\u0627\\u0644\\u0639\\u0644\\u064a\\u0627\",\"type\":\"service\",\"category\":\"police\",\"address\":\"\\u0634\\u0627\\u0631\\u0639 \\u0627\\u0644\\u0639\\u0644\\u064a\\u0627\\u060c \\u0627\\u0644\\u0631\\u064a\\u0627\\u0636\",\"lat\":24.71,\"lng\":46.675,\"icon\":\"\\ud83d\\udc6e\",\"distance\":null},{\"id\":1,\"name\":\"\\u0645\\u0634\\u0631\\u0648\\u0639 \\u062a\\u0637\\u0648\\u064a\\u0631 \\u0637\\u0631\\u064a\\u0642 \\u0627\\u0644\\u0645\\u0644\\u0643 \\u0641\\u0647\\u062f\",\"type\":\"project\",\"category\":\"road\",\"address\":\"\\u0645\\u0646 \\u062a\\u0642\\u0627\\u0637\\u0639 \\u0627\\u0644\\u0639\\u0644\\u064a\\u0627 \\u0625\\u0644\\u0649 \\u062d\\u064a \\u0627\\u0644\\u064a\\u0627\\u0633\\u0645\\u064a\\u0646\",\"lat\":24.72,\"lng\":46.68,\"icon\":\"\\ud83d\\udee3\\ufe0f\",\"status\":\"in_progress\"}],\"total\":3,\"query\":\"\\u0634\\u0631\"}\";s:11:\"\0*\0callback\";N;s:18:\"\0*\0encodingOptions\";i:0;s:8:\"original\";a:3:{s:7:\"results\";a:3:{i:0;a:9:{s:2:\"id\";i:8;s:4:\"name\";s:30:\"مركز شرطة النخيل\";s:4:\"type\";s:7:\"service\";s:8:\"category\";s:6:\"police\";s:7:\"address\";s:41:\"حي النخيل، شمال الرياض\";s:3:\"lat\";d:24.7436;s:3:\"lng\";d:46.7053;s:4:\"icon\";s:4:\"👮\";s:8:\"distance\";N;}i:1;a:9:{s:2:\"id\";i:9;s:4:\"name\";s:30:\"مركز شرطة العليا\";s:4:\"type\";s:7:\"service\";s:8:\"category\";s:6:\"police\";s:7:\"address\";s:36:\"شارع العليا، الرياض\";s:3:\"lat\";d:24.71;s:3:\"lng\";d:46.675;s:4:\"icon\";s:4:\"👮\";s:8:\"distance\";N;}i:2;a:9:{s:2:\"id\";i:1;s:4:\"name\";s:48:\"مشروع تطوير طريق الملك فهد\";s:4:\"type\";s:7:\"project\";s:8:\"category\";s:4:\"road\";s:7:\"address\";s:57:\"من تقاطع العليا إلى حي الياسمين\";s:3:\"lat\";d:24.72;s:3:\"lng\";d:46.68;s:4:\"icon\";s:7:\"🛣️\";s:6:\"status\";s:11:\"in_progress\";}}s:5:\"total\";i:3;s:5:\"query\";s:4:\"شر\";}s:9:\"exception\";N;}',1764425432),('absher-cache-search_602846862b12278addb7f8f5402aefd4','O:28:\"Illuminate\\Http\\JsonResponse\":11:{s:7:\"headers\";O:50:\"Symfony\\Component\\HttpFoundation\\ResponseHeaderBag\":5:{s:10:\"\0*\0headers\";a:3:{s:13:\"cache-control\";a:1:{i:0;s:17:\"no-cache, private\";}s:4:\"date\";a:1:{i:0;s:29:\"Sat, 29 Nov 2025 14:05:41 GMT\";}s:12:\"content-type\";a:1:{i:0;s:16:\"application/json\";}}s:15:\"\0*\0cacheControl\";a:0:{}s:23:\"\0*\0computedCacheControl\";a:2:{s:8:\"no-cache\";b:1;s:7:\"private\";b:1;}s:10:\"\0*\0cookies\";a:0:{}s:14:\"\0*\0headerNames\";a:3:{s:13:\"cache-control\";s:13:\"Cache-Control\";s:4:\"date\";s:4:\"Date\";s:12:\"content-type\";s:12:\"Content-Type\";}}s:10:\"\0*\0content\";s:90:\"{\"results\":[],\"total\":0,\"query\":\"\\u0645\\u0631\\u0643\\u0632 \\u0627\\u0644\\u0627\\u0645\\u0646\"}\";s:10:\"\0*\0version\";s:3:\"1.0\";s:13:\"\0*\0statusCode\";i:200;s:13:\"\0*\0statusText\";s:2:\"OK\";s:10:\"\0*\0charset\";N;s:7:\"\0*\0data\";s:90:\"{\"results\":[],\"total\":0,\"query\":\"\\u0645\\u0631\\u0643\\u0632 \\u0627\\u0644\\u0627\\u0645\\u0646\"}\";s:11:\"\0*\0callback\";N;s:18:\"\0*\0encodingOptions\";i:0;s:8:\"original\";a:3:{s:7:\"results\";a:0:{}s:5:\"total\";i:0;s:5:\"query\";s:19:\"مركز الامن\";}s:9:\"exception\";N;}',1764425441),('absher-cache-search_6c4797ead1e558225489235bb11307f0','O:28:\"Illuminate\\Http\\JsonResponse\":11:{s:7:\"headers\";O:50:\"Symfony\\Component\\HttpFoundation\\ResponseHeaderBag\":5:{s:10:\"\0*\0headers\";a:3:{s:13:\"cache-control\";a:1:{i:0;s:17:\"no-cache, private\";}s:4:\"date\";a:1:{i:0;s:29:\"Sat, 29 Nov 2025 14:05:39 GMT\";}s:12:\"content-type\";a:1:{i:0;s:16:\"application/json\";}}s:15:\"\0*\0cacheControl\";a:0:{}s:23:\"\0*\0computedCacheControl\";a:2:{s:8:\"no-cache\";b:1;s:7:\"private\";b:1;}s:10:\"\0*\0cookies\";a:0:{}s:14:\"\0*\0headerNames\";a:3:{s:13:\"cache-control\";s:13:\"Cache-Control\";s:4:\"date\";s:4:\"Date\";s:12:\"content-type\";s:12:\"Content-Type\";}}s:10:\"\0*\0content\";s:2372:\"{\"results\":[{\"id\":4,\"name\":\"\\u0645\\u0631\\u0643\\u0632 \\u0627\\u0644\\u0625\\u0633\\u0639\\u0627\\u0641 \\u0627\\u0644\\u0631\\u0626\\u064a\\u0633\\u064a\",\"type\":\"service\",\"category\":\"ambulance\",\"address\":\"\\u0634\\u0627\\u0631\\u0639 \\u0627\\u0644\\u0639\\u0644\\u064a\\u0627\\u060c \\u062d\\u064a \\u0627\\u0644\\u0639\\u0644\\u064a\\u0627\\u060c \\u0627\\u0644\\u0631\\u064a\\u0627\\u0636\",\"lat\":24.7036,\"lng\":46.6653,\"icon\":\"\\ud83d\\ude91\",\"distance\":null},{\"id\":5,\"name\":\"\\u0645\\u0631\\u0643\\u0632 \\u0627\\u0644\\u0625\\u0633\\u0639\\u0627\\u0641 \\u0627\\u0644\\u0634\\u0645\\u0627\\u0644\\u064a\",\"type\":\"service\",\"category\":\"ambulance\",\"address\":\"\\u0637\\u0631\\u064a\\u0642 \\u0627\\u0644\\u062f\\u0627\\u0626\\u0631\\u064a \\u0627\\u0644\\u0634\\u0645\\u0627\\u0644\\u064a\\u060c \\u0627\\u0644\\u0631\\u064a\\u0627\\u0636\",\"lat\":24.785,\"lng\":46.67,\"icon\":\"\\ud83d\\ude91\",\"distance\":null},{\"id\":6,\"name\":\"\\u0627\\u0644\\u062f\\u0641\\u0627\\u0639 \\u0627\\u0644\\u0645\\u062f\\u0646\\u064a - \\u0627\\u0644\\u0645\\u0631\\u0643\\u0632 \\u0627\\u0644\\u0631\\u0626\\u064a\\u0633\\u064a\",\"type\":\"service\",\"category\":\"fire_station\",\"address\":\"\\u0637\\u0631\\u064a\\u0642 \\u0627\\u0644\\u0645\\u0644\\u0643 \\u0639\\u0628\\u062f\\u0627\\u0644\\u0639\\u0632\\u064a\\u0632\\u060c \\u062d\\u064a \\u0627\\u0644\\u0645\\u0631\\u0628\\u0639\\u060c \\u0627\\u0644\\u0631\\u064a\\u0627\\u0636\",\"lat\":24.7336,\"lng\":46.6953,\"icon\":\"\\ud83d\\ude92\",\"distance\":null},{\"id\":8,\"name\":\"\\u0645\\u0631\\u0643\\u0632 \\u0634\\u0631\\u0637\\u0629 \\u0627\\u0644\\u0646\\u062e\\u064a\\u0644\",\"type\":\"service\",\"category\":\"police\",\"address\":\"\\u062d\\u064a \\u0627\\u0644\\u0646\\u062e\\u064a\\u0644\\u060c \\u0634\\u0645\\u0627\\u0644 \\u0627\\u0644\\u0631\\u064a\\u0627\\u0636\",\"lat\":24.7436,\"lng\":46.7053,\"icon\":\"\\ud83d\\udc6e\",\"distance\":null},{\"id\":9,\"name\":\"\\u0645\\u0631\\u0643\\u0632 \\u0634\\u0631\\u0637\\u0629 \\u0627\\u0644\\u0639\\u0644\\u064a\\u0627\",\"type\":\"service\",\"category\":\"police\",\"address\":\"\\u0634\\u0627\\u0631\\u0639 \\u0627\\u0644\\u0639\\u0644\\u064a\\u0627\\u060c \\u0627\\u0644\\u0631\\u064a\\u0627\\u0636\",\"lat\":24.71,\"lng\":46.675,\"icon\":\"\\ud83d\\udc6e\",\"distance\":null},{\"id\":10,\"name\":\"\\u0645\\u0631\\u0643\\u0632 \\u0627\\u0644\\u0623\\u0645\\u0646 \\u0627\\u0644\\u0634\\u0627\\u0645\\u0644\",\"type\":\"service\",\"category\":\"police\",\"address\":\"\\u0637\\u0631\\u064a\\u0642 \\u0627\\u0644\\u0645\\u0644\\u0643 \\u0641\\u0647\\u062f\\u060c \\u0627\\u0644\\u0631\\u064a\\u0627\\u0636\",\"lat\":24.715,\"lng\":46.685,\"icon\":\"\\ud83d\\udc6e\",\"distance\":null}],\"total\":6,\"query\":\"\\u0645\\u0631\\u0643\\u0632\"}\";s:10:\"\0*\0version\";s:3:\"1.0\";s:13:\"\0*\0statusCode\";i:200;s:13:\"\0*\0statusText\";s:2:\"OK\";s:10:\"\0*\0charset\";N;s:7:\"\0*\0data\";s:2372:\"{\"results\":[{\"id\":4,\"name\":\"\\u0645\\u0631\\u0643\\u0632 \\u0627\\u0644\\u0625\\u0633\\u0639\\u0627\\u0641 \\u0627\\u0644\\u0631\\u0626\\u064a\\u0633\\u064a\",\"type\":\"service\",\"category\":\"ambulance\",\"address\":\"\\u0634\\u0627\\u0631\\u0639 \\u0627\\u0644\\u0639\\u0644\\u064a\\u0627\\u060c \\u062d\\u064a \\u0627\\u0644\\u0639\\u0644\\u064a\\u0627\\u060c \\u0627\\u0644\\u0631\\u064a\\u0627\\u0636\",\"lat\":24.7036,\"lng\":46.6653,\"icon\":\"\\ud83d\\ude91\",\"distance\":null},{\"id\":5,\"name\":\"\\u0645\\u0631\\u0643\\u0632 \\u0627\\u0644\\u0625\\u0633\\u0639\\u0627\\u0641 \\u0627\\u0644\\u0634\\u0645\\u0627\\u0644\\u064a\",\"type\":\"service\",\"category\":\"ambulance\",\"address\":\"\\u0637\\u0631\\u064a\\u0642 \\u0627\\u0644\\u062f\\u0627\\u0626\\u0631\\u064a \\u0627\\u0644\\u0634\\u0645\\u0627\\u0644\\u064a\\u060c \\u0627\\u0644\\u0631\\u064a\\u0627\\u0636\",\"lat\":24.785,\"lng\":46.67,\"icon\":\"\\ud83d\\ude91\",\"distance\":null},{\"id\":6,\"name\":\"\\u0627\\u0644\\u062f\\u0641\\u0627\\u0639 \\u0627\\u0644\\u0645\\u062f\\u0646\\u064a - \\u0627\\u0644\\u0645\\u0631\\u0643\\u0632 \\u0627\\u0644\\u0631\\u0626\\u064a\\u0633\\u064a\",\"type\":\"service\",\"category\":\"fire_station\",\"address\":\"\\u0637\\u0631\\u064a\\u0642 \\u0627\\u0644\\u0645\\u0644\\u0643 \\u0639\\u0628\\u062f\\u0627\\u0644\\u0639\\u0632\\u064a\\u0632\\u060c \\u062d\\u064a \\u0627\\u0644\\u0645\\u0631\\u0628\\u0639\\u060c \\u0627\\u0644\\u0631\\u064a\\u0627\\u0636\",\"lat\":24.7336,\"lng\":46.6953,\"icon\":\"\\ud83d\\ude92\",\"distance\":null},{\"id\":8,\"name\":\"\\u0645\\u0631\\u0643\\u0632 \\u0634\\u0631\\u0637\\u0629 \\u0627\\u0644\\u0646\\u062e\\u064a\\u0644\",\"type\":\"service\",\"category\":\"police\",\"address\":\"\\u062d\\u064a \\u0627\\u0644\\u0646\\u062e\\u064a\\u0644\\u060c \\u0634\\u0645\\u0627\\u0644 \\u0627\\u0644\\u0631\\u064a\\u0627\\u0636\",\"lat\":24.7436,\"lng\":46.7053,\"icon\":\"\\ud83d\\udc6e\",\"distance\":null},{\"id\":9,\"name\":\"\\u0645\\u0631\\u0643\\u0632 \\u0634\\u0631\\u0637\\u0629 \\u0627\\u0644\\u0639\\u0644\\u064a\\u0627\",\"type\":\"service\",\"category\":\"police\",\"address\":\"\\u0634\\u0627\\u0631\\u0639 \\u0627\\u0644\\u0639\\u0644\\u064a\\u0627\\u060c \\u0627\\u0644\\u0631\\u064a\\u0627\\u0636\",\"lat\":24.71,\"lng\":46.675,\"icon\":\"\\ud83d\\udc6e\",\"distance\":null},{\"id\":10,\"name\":\"\\u0645\\u0631\\u0643\\u0632 \\u0627\\u0644\\u0623\\u0645\\u0646 \\u0627\\u0644\\u0634\\u0627\\u0645\\u0644\",\"type\":\"service\",\"category\":\"police\",\"address\":\"\\u0637\\u0631\\u064a\\u0642 \\u0627\\u0644\\u0645\\u0644\\u0643 \\u0641\\u0647\\u062f\\u060c \\u0627\\u0644\\u0631\\u064a\\u0627\\u0636\",\"lat\":24.715,\"lng\":46.685,\"icon\":\"\\ud83d\\udc6e\",\"distance\":null}],\"total\":6,\"query\":\"\\u0645\\u0631\\u0643\\u0632\"}\";s:11:\"\0*\0callback\";N;s:18:\"\0*\0encodingOptions\";i:0;s:8:\"original\";a:3:{s:7:\"results\";a:6:{i:0;a:9:{s:2:\"id\";i:4;s:4:\"name\";s:38:\"مركز الإسعاف الرئيسي\";s:4:\"type\";s:7:\"service\";s:8:\"category\";s:9:\"ambulance\";s:7:\"address\";s:56:\"شارع العليا، حي العليا، الرياض\";s:3:\"lat\";d:24.7036;s:3:\"lng\";d:46.6653;s:4:\"icon\";s:4:\"🚑\";s:8:\"distance\";N;}i:1;a:9:{s:2:\"id\";i:5;s:4:\"name\";s:38:\"مركز الإسعاف الشمالي\";s:4:\"type\";s:7:\"service\";s:8:\"category\";s:9:\"ambulance\";s:7:\"address\";s:53:\"طريق الدائري الشمالي، الرياض\";s:3:\"lat\";d:24.785;s:3:\"lng\";d:46.67;s:4:\"icon\";s:4:\"🚑\";s:8:\"distance\";N;}i:2;a:9:{s:2:\"id\";i:6;s:4:\"name\";s:55:\"الدفاع المدني - المركز الرئيسي\";s:4:\"type\";s:7:\"service\";s:8:\"category\";s:12:\"fire_station\";s:7:\"address\";s:73:\"طريق الملك عبدالعزيز، حي المربع، الرياض\";s:3:\"lat\";d:24.7336;s:3:\"lng\";d:46.6953;s:4:\"icon\";s:4:\"🚒\";s:8:\"distance\";N;}i:3;a:9:{s:2:\"id\";i:8;s:4:\"name\";s:30:\"مركز شرطة النخيل\";s:4:\"type\";s:7:\"service\";s:8:\"category\";s:6:\"police\";s:7:\"address\";s:41:\"حي النخيل، شمال الرياض\";s:3:\"lat\";d:24.7436;s:3:\"lng\";d:46.7053;s:4:\"icon\";s:4:\"👮\";s:8:\"distance\";N;}i:4;a:9:{s:2:\"id\";i:9;s:4:\"name\";s:30:\"مركز شرطة العليا\";s:4:\"type\";s:7:\"service\";s:8:\"category\";s:6:\"police\";s:7:\"address\";s:36:\"شارع العليا، الرياض\";s:3:\"lat\";d:24.71;s:3:\"lng\";d:46.675;s:4:\"icon\";s:4:\"👮\";s:8:\"distance\";N;}i:5;a:9:{s:2:\"id\";i:10;s:4:\"name\";s:32:\"مركز الأمن الشامل\";s:4:\"type\";s:7:\"service\";s:8:\"category\";s:6:\"police\";s:7:\"address\";s:41:\"طريق الملك فهد، الرياض\";s:3:\"lat\";d:24.715;s:3:\"lng\";d:46.685;s:4:\"icon\";s:4:\"👮\";s:8:\"distance\";N;}}s:5:\"total\";i:6;s:5:\"query\";s:8:\"مركز\";}s:9:\"exception\";N;}',1764425439),('absher-cache-search_7492113d6d647a29d4a8e6b3a83d65b0','O:28:\"Illuminate\\Http\\JsonResponse\":11:{s:7:\"headers\";O:50:\"Symfony\\Component\\HttpFoundation\\ResponseHeaderBag\":5:{s:10:\"\0*\0headers\";a:3:{s:13:\"cache-control\";a:1:{i:0;s:17:\"no-cache, private\";}s:4:\"date\";a:1:{i:0;s:29:\"Sat, 29 Nov 2025 14:05:39 GMT\";}s:12:\"content-type\";a:1:{i:0;s:16:\"application/json\";}}s:15:\"\0*\0cacheControl\";a:0:{}s:23:\"\0*\0computedCacheControl\";a:2:{s:8:\"no-cache\";b:1;s:7:\"private\";b:1;}s:10:\"\0*\0cookies\";a:0:{}s:14:\"\0*\0headerNames\";a:3:{s:13:\"cache-control\";s:13:\"Cache-Control\";s:4:\"date\";s:4:\"Date\";s:12:\"content-type\";s:12:\"Content-Type\";}}s:10:\"\0*\0content\";s:2366:\"{\"results\":[{\"id\":4,\"name\":\"\\u0645\\u0631\\u0643\\u0632 \\u0627\\u0644\\u0625\\u0633\\u0639\\u0627\\u0641 \\u0627\\u0644\\u0631\\u0626\\u064a\\u0633\\u064a\",\"type\":\"service\",\"category\":\"ambulance\",\"address\":\"\\u0634\\u0627\\u0631\\u0639 \\u0627\\u0644\\u0639\\u0644\\u064a\\u0627\\u060c \\u062d\\u064a \\u0627\\u0644\\u0639\\u0644\\u064a\\u0627\\u060c \\u0627\\u0644\\u0631\\u064a\\u0627\\u0636\",\"lat\":24.7036,\"lng\":46.6653,\"icon\":\"\\ud83d\\ude91\",\"distance\":null},{\"id\":5,\"name\":\"\\u0645\\u0631\\u0643\\u0632 \\u0627\\u0644\\u0625\\u0633\\u0639\\u0627\\u0641 \\u0627\\u0644\\u0634\\u0645\\u0627\\u0644\\u064a\",\"type\":\"service\",\"category\":\"ambulance\",\"address\":\"\\u0637\\u0631\\u064a\\u0642 \\u0627\\u0644\\u062f\\u0627\\u0626\\u0631\\u064a \\u0627\\u0644\\u0634\\u0645\\u0627\\u0644\\u064a\\u060c \\u0627\\u0644\\u0631\\u064a\\u0627\\u0636\",\"lat\":24.785,\"lng\":46.67,\"icon\":\"\\ud83d\\ude91\",\"distance\":null},{\"id\":6,\"name\":\"\\u0627\\u0644\\u062f\\u0641\\u0627\\u0639 \\u0627\\u0644\\u0645\\u062f\\u0646\\u064a - \\u0627\\u0644\\u0645\\u0631\\u0643\\u0632 \\u0627\\u0644\\u0631\\u0626\\u064a\\u0633\\u064a\",\"type\":\"service\",\"category\":\"fire_station\",\"address\":\"\\u0637\\u0631\\u064a\\u0642 \\u0627\\u0644\\u0645\\u0644\\u0643 \\u0639\\u0628\\u062f\\u0627\\u0644\\u0639\\u0632\\u064a\\u0632\\u060c \\u062d\\u064a \\u0627\\u0644\\u0645\\u0631\\u0628\\u0639\\u060c \\u0627\\u0644\\u0631\\u064a\\u0627\\u0636\",\"lat\":24.7336,\"lng\":46.6953,\"icon\":\"\\ud83d\\ude92\",\"distance\":null},{\"id\":8,\"name\":\"\\u0645\\u0631\\u0643\\u0632 \\u0634\\u0631\\u0637\\u0629 \\u0627\\u0644\\u0646\\u062e\\u064a\\u0644\",\"type\":\"service\",\"category\":\"police\",\"address\":\"\\u062d\\u064a \\u0627\\u0644\\u0646\\u062e\\u064a\\u0644\\u060c \\u0634\\u0645\\u0627\\u0644 \\u0627\\u0644\\u0631\\u064a\\u0627\\u0636\",\"lat\":24.7436,\"lng\":46.7053,\"icon\":\"\\ud83d\\udc6e\",\"distance\":null},{\"id\":9,\"name\":\"\\u0645\\u0631\\u0643\\u0632 \\u0634\\u0631\\u0637\\u0629 \\u0627\\u0644\\u0639\\u0644\\u064a\\u0627\",\"type\":\"service\",\"category\":\"police\",\"address\":\"\\u0634\\u0627\\u0631\\u0639 \\u0627\\u0644\\u0639\\u0644\\u064a\\u0627\\u060c \\u0627\\u0644\\u0631\\u064a\\u0627\\u0636\",\"lat\":24.71,\"lng\":46.675,\"icon\":\"\\ud83d\\udc6e\",\"distance\":null},{\"id\":10,\"name\":\"\\u0645\\u0631\\u0643\\u0632 \\u0627\\u0644\\u0623\\u0645\\u0646 \\u0627\\u0644\\u0634\\u0627\\u0645\\u0644\",\"type\":\"service\",\"category\":\"police\",\"address\":\"\\u0637\\u0631\\u064a\\u0642 \\u0627\\u0644\\u0645\\u0644\\u0643 \\u0641\\u0647\\u062f\\u060c \\u0627\\u0644\\u0631\\u064a\\u0627\\u0636\",\"lat\":24.715,\"lng\":46.685,\"icon\":\"\\ud83d\\udc6e\",\"distance\":null}],\"total\":6,\"query\":\"\\u0645\\u0631\\u0643\"}\";s:10:\"\0*\0version\";s:3:\"1.0\";s:13:\"\0*\0statusCode\";i:200;s:13:\"\0*\0statusText\";s:2:\"OK\";s:10:\"\0*\0charset\";N;s:7:\"\0*\0data\";s:2366:\"{\"results\":[{\"id\":4,\"name\":\"\\u0645\\u0631\\u0643\\u0632 \\u0627\\u0644\\u0625\\u0633\\u0639\\u0627\\u0641 \\u0627\\u0644\\u0631\\u0626\\u064a\\u0633\\u064a\",\"type\":\"service\",\"category\":\"ambulance\",\"address\":\"\\u0634\\u0627\\u0631\\u0639 \\u0627\\u0644\\u0639\\u0644\\u064a\\u0627\\u060c \\u062d\\u064a \\u0627\\u0644\\u0639\\u0644\\u064a\\u0627\\u060c \\u0627\\u0644\\u0631\\u064a\\u0627\\u0636\",\"lat\":24.7036,\"lng\":46.6653,\"icon\":\"\\ud83d\\ude91\",\"distance\":null},{\"id\":5,\"name\":\"\\u0645\\u0631\\u0643\\u0632 \\u0627\\u0644\\u0625\\u0633\\u0639\\u0627\\u0641 \\u0627\\u0644\\u0634\\u0645\\u0627\\u0644\\u064a\",\"type\":\"service\",\"category\":\"ambulance\",\"address\":\"\\u0637\\u0631\\u064a\\u0642 \\u0627\\u0644\\u062f\\u0627\\u0626\\u0631\\u064a \\u0627\\u0644\\u0634\\u0645\\u0627\\u0644\\u064a\\u060c \\u0627\\u0644\\u0631\\u064a\\u0627\\u0636\",\"lat\":24.785,\"lng\":46.67,\"icon\":\"\\ud83d\\ude91\",\"distance\":null},{\"id\":6,\"name\":\"\\u0627\\u0644\\u062f\\u0641\\u0627\\u0639 \\u0627\\u0644\\u0645\\u062f\\u0646\\u064a - \\u0627\\u0644\\u0645\\u0631\\u0643\\u0632 \\u0627\\u0644\\u0631\\u0626\\u064a\\u0633\\u064a\",\"type\":\"service\",\"category\":\"fire_station\",\"address\":\"\\u0637\\u0631\\u064a\\u0642 \\u0627\\u0644\\u0645\\u0644\\u0643 \\u0639\\u0628\\u062f\\u0627\\u0644\\u0639\\u0632\\u064a\\u0632\\u060c \\u062d\\u064a \\u0627\\u0644\\u0645\\u0631\\u0628\\u0639\\u060c \\u0627\\u0644\\u0631\\u064a\\u0627\\u0636\",\"lat\":24.7336,\"lng\":46.6953,\"icon\":\"\\ud83d\\ude92\",\"distance\":null},{\"id\":8,\"name\":\"\\u0645\\u0631\\u0643\\u0632 \\u0634\\u0631\\u0637\\u0629 \\u0627\\u0644\\u0646\\u062e\\u064a\\u0644\",\"type\":\"service\",\"category\":\"police\",\"address\":\"\\u062d\\u064a \\u0627\\u0644\\u0646\\u062e\\u064a\\u0644\\u060c \\u0634\\u0645\\u0627\\u0644 \\u0627\\u0644\\u0631\\u064a\\u0627\\u0636\",\"lat\":24.7436,\"lng\":46.7053,\"icon\":\"\\ud83d\\udc6e\",\"distance\":null},{\"id\":9,\"name\":\"\\u0645\\u0631\\u0643\\u0632 \\u0634\\u0631\\u0637\\u0629 \\u0627\\u0644\\u0639\\u0644\\u064a\\u0627\",\"type\":\"service\",\"category\":\"police\",\"address\":\"\\u0634\\u0627\\u0631\\u0639 \\u0627\\u0644\\u0639\\u0644\\u064a\\u0627\\u060c \\u0627\\u0644\\u0631\\u064a\\u0627\\u0636\",\"lat\":24.71,\"lng\":46.675,\"icon\":\"\\ud83d\\udc6e\",\"distance\":null},{\"id\":10,\"name\":\"\\u0645\\u0631\\u0643\\u0632 \\u0627\\u0644\\u0623\\u0645\\u0646 \\u0627\\u0644\\u0634\\u0627\\u0645\\u0644\",\"type\":\"service\",\"category\":\"police\",\"address\":\"\\u0637\\u0631\\u064a\\u0642 \\u0627\\u0644\\u0645\\u0644\\u0643 \\u0641\\u0647\\u062f\\u060c \\u0627\\u0644\\u0631\\u064a\\u0627\\u0636\",\"lat\":24.715,\"lng\":46.685,\"icon\":\"\\ud83d\\udc6e\",\"distance\":null}],\"total\":6,\"query\":\"\\u0645\\u0631\\u0643\"}\";s:11:\"\0*\0callback\";N;s:18:\"\0*\0encodingOptions\";i:0;s:8:\"original\";a:3:{s:7:\"results\";a:6:{i:0;a:9:{s:2:\"id\";i:4;s:4:\"name\";s:38:\"مركز الإسعاف الرئيسي\";s:4:\"type\";s:7:\"service\";s:8:\"category\";s:9:\"ambulance\";s:7:\"address\";s:56:\"شارع العليا، حي العليا، الرياض\";s:3:\"lat\";d:24.7036;s:3:\"lng\";d:46.6653;s:4:\"icon\";s:4:\"🚑\";s:8:\"distance\";N;}i:1;a:9:{s:2:\"id\";i:5;s:4:\"name\";s:38:\"مركز الإسعاف الشمالي\";s:4:\"type\";s:7:\"service\";s:8:\"category\";s:9:\"ambulance\";s:7:\"address\";s:53:\"طريق الدائري الشمالي، الرياض\";s:3:\"lat\";d:24.785;s:3:\"lng\";d:46.67;s:4:\"icon\";s:4:\"🚑\";s:8:\"distance\";N;}i:2;a:9:{s:2:\"id\";i:6;s:4:\"name\";s:55:\"الدفاع المدني - المركز الرئيسي\";s:4:\"type\";s:7:\"service\";s:8:\"category\";s:12:\"fire_station\";s:7:\"address\";s:73:\"طريق الملك عبدالعزيز، حي المربع، الرياض\";s:3:\"lat\";d:24.7336;s:3:\"lng\";d:46.6953;s:4:\"icon\";s:4:\"🚒\";s:8:\"distance\";N;}i:3;a:9:{s:2:\"id\";i:8;s:4:\"name\";s:30:\"مركز شرطة النخيل\";s:4:\"type\";s:7:\"service\";s:8:\"category\";s:6:\"police\";s:7:\"address\";s:41:\"حي النخيل، شمال الرياض\";s:3:\"lat\";d:24.7436;s:3:\"lng\";d:46.7053;s:4:\"icon\";s:4:\"👮\";s:8:\"distance\";N;}i:4;a:9:{s:2:\"id\";i:9;s:4:\"name\";s:30:\"مركز شرطة العليا\";s:4:\"type\";s:7:\"service\";s:8:\"category\";s:6:\"police\";s:7:\"address\";s:36:\"شارع العليا، الرياض\";s:3:\"lat\";d:24.71;s:3:\"lng\";d:46.675;s:4:\"icon\";s:4:\"👮\";s:8:\"distance\";N;}i:5;a:9:{s:2:\"id\";i:10;s:4:\"name\";s:32:\"مركز الأمن الشامل\";s:4:\"type\";s:7:\"service\";s:8:\"category\";s:6:\"police\";s:7:\"address\";s:41:\"طريق الملك فهد، الرياض\";s:3:\"lat\";d:24.715;s:3:\"lng\";d:46.685;s:4:\"icon\";s:4:\"👮\";s:8:\"distance\";N;}}s:5:\"total\";i:6;s:5:\"query\";s:6:\"مرك\";}s:9:\"exception\";N;}',1764425439),('absher-cache-search_b263848cc9d937432d41f7798cfb7cd8','O:28:\"Illuminate\\Http\\JsonResponse\":11:{s:7:\"headers\";O:50:\"Symfony\\Component\\HttpFoundation\\ResponseHeaderBag\":5:{s:10:\"\0*\0headers\";a:3:{s:13:\"cache-control\";a:1:{i:0;s:17:\"no-cache, private\";}s:4:\"date\";a:1:{i:0;s:29:\"Sat, 29 Nov 2025 10:43:47 GMT\";}s:12:\"content-type\";a:1:{i:0;s:16:\"application/json\";}}s:15:\"\0*\0cacheControl\";a:0:{}s:23:\"\0*\0computedCacheControl\";a:2:{s:8:\"no-cache\";b:1;s:7:\"private\";b:1;}s:10:\"\0*\0cookies\";a:0:{}s:14:\"\0*\0headerNames\";a:3:{s:13:\"cache-control\";s:13:\"Cache-Control\";s:4:\"date\";s:4:\"Date\";s:12:\"content-type\";s:12:\"Content-Type\";}}s:10:\"\0*\0content\";s:65:\"{\"results\":[],\"total\":0,\"query\":\"\\u062c\\u0648\\u0627\\u0632\\u0627\"}\";s:10:\"\0*\0version\";s:3:\"1.0\";s:13:\"\0*\0statusCode\";i:200;s:13:\"\0*\0statusText\";s:2:\"OK\";s:10:\"\0*\0charset\";N;s:7:\"\0*\0data\";s:65:\"{\"results\":[],\"total\":0,\"query\":\"\\u062c\\u0648\\u0627\\u0632\\u0627\"}\";s:11:\"\0*\0callback\";N;s:18:\"\0*\0encodingOptions\";i:0;s:8:\"original\";a:3:{s:7:\"results\";a:0:{}s:5:\"total\";i:0;s:5:\"query\";s:10:\"جوازا\";}s:9:\"exception\";N;}',1764413327),('absher-cache-search_b8dd9cab3bd14e93427248d2d86aae52','O:28:\"Illuminate\\Http\\JsonResponse\":11:{s:7:\"headers\";O:50:\"Symfony\\Component\\HttpFoundation\\ResponseHeaderBag\":5:{s:10:\"\0*\0headers\";a:3:{s:13:\"cache-control\";a:1:{i:0;s:17:\"no-cache, private\";}s:4:\"date\";a:1:{i:0;s:29:\"Sat, 29 Nov 2025 10:37:43 GMT\";}s:12:\"content-type\";a:1:{i:0;s:16:\"application/json\";}}s:15:\"\0*\0cacheControl\";a:0:{}s:23:\"\0*\0computedCacheControl\";a:2:{s:8:\"no-cache\";b:1;s:7:\"private\";b:1;}s:10:\"\0*\0cookies\";a:0:{}s:14:\"\0*\0headerNames\";a:3:{s:13:\"cache-control\";s:13:\"Cache-Control\";s:4:\"date\";s:4:\"Date\";s:12:\"content-type\";s:12:\"Content-Type\";}}s:10:\"\0*\0content\";s:47:\"{\"results\":[],\"total\":0,\"query\":\"\\u0628\\u0628\"}\";s:10:\"\0*\0version\";s:3:\"1.0\";s:13:\"\0*\0statusCode\";i:200;s:13:\"\0*\0statusText\";s:2:\"OK\";s:10:\"\0*\0charset\";N;s:7:\"\0*\0data\";s:47:\"{\"results\":[],\"total\":0,\"query\":\"\\u0628\\u0628\"}\";s:11:\"\0*\0callback\";N;s:18:\"\0*\0encodingOptions\";i:0;s:8:\"original\";a:3:{s:7:\"results\";a:0:{}s:5:\"total\";i:0;s:5:\"query\";s:4:\"بب\";}s:9:\"exception\";N;}',1764412963),('absher-cache-search_c7e55b6a0efb6a2a9564c91f25dcaca3','O:28:\"Illuminate\\Http\\JsonResponse\":11:{s:7:\"headers\";O:50:\"Symfony\\Component\\HttpFoundation\\ResponseHeaderBag\":5:{s:10:\"\0*\0headers\";a:3:{s:13:\"cache-control\";a:1:{i:0;s:17:\"no-cache, private\";}s:4:\"date\";a:1:{i:0;s:29:\"Sat, 29 Nov 2025 14:05:42 GMT\";}s:12:\"content-type\";a:1:{i:0;s:16:\"application/json\";}}s:15:\"\0*\0cacheControl\";a:0:{}s:23:\"\0*\0computedCacheControl\";a:2:{s:8:\"no-cache\";b:1;s:7:\"private\";b:1;}s:10:\"\0*\0cookies\";a:0:{}s:14:\"\0*\0headerNames\";a:3:{s:13:\"cache-control\";s:13:\"Cache-Control\";s:4:\"date\";s:4:\"Date\";s:12:\"content-type\";s:12:\"Content-Type\";}}s:10:\"\0*\0content\";s:84:\"{\"results\":[],\"total\":0,\"query\":\"\\u0645\\u0631\\u0643\\u0632 \\u0627\\u0644\\u0627\\u0645\"}\";s:10:\"\0*\0version\";s:3:\"1.0\";s:13:\"\0*\0statusCode\";i:200;s:13:\"\0*\0statusText\";s:2:\"OK\";s:10:\"\0*\0charset\";N;s:7:\"\0*\0data\";s:84:\"{\"results\":[],\"total\":0,\"query\":\"\\u0645\\u0631\\u0643\\u0632 \\u0627\\u0644\\u0627\\u0645\"}\";s:11:\"\0*\0callback\";N;s:18:\"\0*\0encodingOptions\";i:0;s:8:\"original\";a:3:{s:7:\"results\";a:0:{}s:5:\"total\";i:0;s:5:\"query\";s:17:\"مركز الام\";}s:9:\"exception\";N;}',1764425442),('absher-cache-search_ec701afa0050dc048482fc5be888212b','O:28:\"Illuminate\\Http\\JsonResponse\":11:{s:7:\"headers\";O:50:\"Symfony\\Component\\HttpFoundation\\ResponseHeaderBag\":5:{s:10:\"\0*\0headers\";a:3:{s:13:\"cache-control\";a:1:{i:0;s:17:\"no-cache, private\";}s:4:\"date\";a:1:{i:0;s:29:\"Sat, 29 Nov 2025 10:43:46 GMT\";}s:12:\"content-type\";a:1:{i:0;s:16:\"application/json\";}}s:15:\"\0*\0cacheControl\";a:0:{}s:23:\"\0*\0computedCacheControl\";a:2:{s:8:\"no-cache\";b:1;s:7:\"private\";b:1;}s:10:\"\0*\0cookies\";a:0:{}s:14:\"\0*\0headerNames\";a:3:{s:13:\"cache-control\";s:13:\"Cache-Control\";s:4:\"date\";s:4:\"Date\";s:12:\"content-type\";s:12:\"Content-Type\";}}s:10:\"\0*\0content\";s:71:\"{\"results\":[],\"total\":0,\"query\":\"\\u062c\\u0648\\u0627\\u0632\\u0627\\u062a\"}\";s:10:\"\0*\0version\";s:3:\"1.0\";s:13:\"\0*\0statusCode\";i:200;s:13:\"\0*\0statusText\";s:2:\"OK\";s:10:\"\0*\0charset\";N;s:7:\"\0*\0data\";s:71:\"{\"results\":[],\"total\":0,\"query\":\"\\u062c\\u0648\\u0627\\u0632\\u0627\\u062a\"}\";s:11:\"\0*\0callback\";N;s:18:\"\0*\0encodingOptions\";i:0;s:8:\"original\";a:3:{s:7:\"results\";a:0:{}s:5:\"total\";i:0;s:5:\"query\";s:12:\"جوازات\";}s:9:\"exception\";N;}',1764413326),('rzyn-cache-admin@falak.sa|127.0.0.1','i:1;',1764441139),('rzyn-cache-admin@falak.sa|127.0.0.1:timer','i:1764441139;',1764441139);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `centers`
--

DROP TABLE IF EXISTS `centers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `centers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'open',
  `geometry` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`geometry`)),
  `properties` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`properties`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `centers_uuid_unique` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `centers`
--

LOCK TABLES `centers` WRITE;
/*!40000 ALTER TABLE `centers` DISABLE KEYS */;
INSERT INTO `centers` VALUES (1,'01666156-1c23-4965-8132-4090e45ff787','مركز الأحوال المدنية - النرجس','government','open','{\"type\":\"Point\",\"coordinates\":[46.715,24.76]}','{\"waiting_time\":\"15 minutes\"}','2025-11-28 16:51:55','2025-11-28 16:51:55'),(2,'324daaec-0ad1-4b87-9062-1d2d7dcb9667','مركز الشرطة - العليا','police','open','{\"type\":\"Point\",\"coordinates\":[46.7,24.75]}','{\"emergency_contact\":\"999\"}','2025-11-28 16:51:55','2025-11-28 16:51:55');
/*!40000 ALTER TABLE `centers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cities`
--

DROP TABLE IF EXISTS `cities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cities` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `name_en` varchar(255) NOT NULL,
  `geometry` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`geometry`)),
  `center_lat` decimal(10,7) NOT NULL,
  `center_lng` decimal(10,7) NOT NULL,
  `population` int(11) DEFAULT NULL,
  `stats` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`stats`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cities_center_lat_center_lng_index` (`center_lat`,`center_lng`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cities`
--

LOCK TABLES `cities` WRITE;
/*!40000 ALTER TABLE `cities` DISABLE KEYS */;
INSERT INTO `cities` VALUES (1,'الرياض','Riyadh','{\"type\":\"Polygon\",\"coordinates\":[[[46.5,24.5],[46.9,24.5],[46.9,24.9],[46.5,24.9],[46.5,24.5]]]}',24.7136000,46.6753000,7000000,'\"{\\\"roads\\\":127,\\\"incidents\\\":3,\\\"projects\\\":47,\\\"avg_wait_time\\\":12}\"','2025-11-28 16:51:43','2025-11-28 16:51:43'),(2,'جدة','Jeddah','{\"type\":\"Polygon\",\"coordinates\":[[[39,21.3],[39.3,21.3],[39.3,21.7],[39,21.7],[39,21.3]]]}',21.5433000,39.1728000,4000000,'\"{\\\"roads\\\":98,\\\"incidents\\\":5,\\\"projects\\\":62,\\\"avg_wait_time\\\":15}\"','2025-11-28 16:51:43','2025-11-28 16:51:43'),(3,'مكة المكرمة','Makkah','{\"type\":\"Polygon\",\"coordinates\":[[[39.7,21.2],[40,21.2],[40,21.5],[39.7,21.5],[39.7,21.2]]]}',21.3891000,39.8579000,2000000,'\"{\\\"roads\\\":75,\\\"incidents\\\":2,\\\"projects\\\":38,\\\"avg_wait_time\\\":18}\"','2025-11-28 16:51:43','2025-11-28 16:51:43'),(4,'الدمام','Dammam','{\"type\":\"Polygon\",\"coordinates\":[[[49.9,26.2],[50.3,26.2],[50.3,26.6],[49.9,26.6],[49.9,26.2]]]}',26.4207000,50.0888000,1500000,'\"{\\\"roads\\\":82,\\\"incidents\\\":4,\\\"projects\\\":35,\\\"avg_wait_time\\\":10}\"','2025-11-28 16:51:44','2025-11-28 16:51:44'),(5,'المدينة المنورة','Madinah','{\"type\":\"Polygon\",\"coordinates\":[[[39.4,24.3],[39.8,24.3],[39.8,24.6],[39.4,24.6],[39.4,24.3]]]}',24.4672000,39.6117000,1500000,'\"{\\\"roads\\\":68,\\\"incidents\\\":1,\\\"projects\\\":42,\\\"avg_wait_time\\\":8}\"','2025-11-28 16:51:44','2025-11-28 16:51:44'),(6,'الطائف','Taif','{\"type\":\"Polygon\",\"coordinates\":[[[40.2,21.1],[40.6,21.1],[40.6,21.4],[40.2,21.4],[40.2,21.1]]]}',21.2703000,40.4175000,1000000,'\"{\\\"roads\\\":54,\\\"incidents\\\":2,\\\"projects\\\":28,\\\"avg_wait_time\\\":14}\"','2025-11-28 16:51:44','2025-11-28 16:51:44'),(7,'تبوك','Tabuk','{\"type\":\"Polygon\",\"coordinates\":[[[36.4,28.2],[36.7,28.2],[36.7,28.5],[36.4,28.5],[36.4,28.2]]]}',28.3838000,36.5676000,900000,'\"{\\\"roads\\\":45,\\\"incidents\\\":1,\\\"projects\\\":22,\\\"avg_wait_time\\\":9}\"','2025-11-28 16:51:44','2025-11-28 16:51:44'),(8,'أبها','Abha','{\"type\":\"Polygon\",\"coordinates\":[[[42.3,18],[42.7,18],[42.7,18.4],[42.3,18.4],[42.3,18]]]}',18.2164000,42.5053000,500000,'\"{\\\"roads\\\":38,\\\"incidents\\\":0,\\\"projects\\\":18,\\\"avg_wait_time\\\":7}\"','2025-11-28 16:51:44','2025-11-28 16:51:44');
/*!40000 ALTER TABLE `cities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `incidents`
--

DROP TABLE IF EXISTS `incidents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `incidents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `title` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'active',
  `severity` varchar(255) DEFAULT NULL,
  `geometry` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`geometry`)),
  `properties` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`properties`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `incidents_uuid_unique` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `incidents`
--

LOCK TABLES `incidents` WRITE;
/*!40000 ALTER TABLE `incidents` DISABLE KEYS */;
INSERT INTO `incidents` VALUES (1,'31f648c8-1331-45b6-9d72-7d76f149ea4e','حادث مروري','active','high','{\"type\":\"Point\",\"coordinates\":[46.6753,24.7136]}','{\"description\":\"\\u062d\\u0627\\u062f\\u062b \\u0645\\u0631\\u0648\\u0631\\u064a \\u0639\\u0644\\u0649 \\u0637\\u0631\\u064a\\u0642 \\u0627\\u0644\\u0645\\u0644\\u0643 \\u0641\\u0647\\u062f\"}','2025-11-28 16:51:47','2025-11-28 16:51:47'),(2,'a1e0dd9b-200e-408e-b60d-ab63ca71b03b','إغلاق طريق','closed','medium','{\"type\":\"Point\",\"coordinates\":[46.7,24.75]}','{\"description\":\"\\u0625\\u063a\\u0644\\u0627\\u0642 \\u0637\\u0631\\u064a\\u0642 \\u0627\\u0644\\u0623\\u0645\\u064a\\u0631 \\u0645\\u062d\\u0645\\u062f \\u0628\\u0646 \\u0633\\u0644\\u0645\\u0627\\u0646 \\u0644\\u0644\\u0635\\u064a\\u0627\\u0646\\u0629\"}','2025-11-28 16:51:47','2025-11-28 16:51:47');
/*!40000 ALTER TABLE `incidents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `layers`
--

DROP TABLE IF EXISTS `layers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `layers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `properties` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`properties`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `layers`
--

LOCK TABLES `layers` WRITE;
/*!40000 ALTER TABLE `layers` DISABLE KEYS */;
/*!40000 ALTER TABLE `layers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2023_01_01_000001_create_incidents_table',1),(5,'2023_01_01_000002_create_projects_table',1),(6,'2023_01_01_000003_create_centers_table',1),(7,'2023_01_01_000004_create_layers_table',1),(8,'2025_01_03_000001_create_roads_table',1),(9,'2025_01_03_000002_create_traffic_table',1),(10,'2025_01_03_000003_create_cities_table',1),(11,'2025_11_28_183154_create_personal_access_tokens_table',1),(12,'2025_11_28_183159_create_permission_tables',1),(13,'2024_xx_xx_add_role_to_users_table',2),(14,'2025_11_29_114943_add_role_to_users_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_permissions`
--

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_roles`
--

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` text NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`),
  KEY `personal_access_tokens_expires_at_index` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projects` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `geometry` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`geometry`)),
  `properties` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`properties`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `projects_uuid_unique` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
INSERT INTO `projects` VALUES (1,'47f9ca94-8a9e-4000-b7be-914c95dcbdcc','مشروع تطوير طريق الملك عبدالعزيز','road','in-progress','{\"type\":\"LineString\",\"coordinates\":[[46.7,24.75],[46.71,24.76]]}','{\"budget\":\"10M SAR\",\"deadline\":\"2024-12-31\"}','2025-11-28 16:51:51','2025-11-28 16:51:51'),(2,'727d4fe7-c2ea-42f0-84a9-b09ace0a62cd','إنشاء حديقة عامة','park','completed','{\"type\":\"Polygon\",\"coordinates\":[[[46.72,24.77],[46.725,24.77],[46.725,24.775],[46.72,24.775],[46.72,24.77]]]}','{\"area\":\"5000 sqm\"}','2025-11-28 16:51:51','2025-11-28 16:51:51');
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roads`
--

DROP TABLE IF EXISTS `roads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roads` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` enum('open','closed','maintenance') NOT NULL DEFAULT 'open',
  `geometry` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`geometry`)),
  `properties` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`properties`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roads_uuid_unique` (`uuid`),
  KEY `roads_status_index` (`status`),
  KEY `roads_name_index` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roads`
--

LOCK TABLES `roads` WRITE;
/*!40000 ALTER TABLE `roads` DISABLE KEYS */;
/*!40000 ALTER TABLE `roads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_has_permissions`
--

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('EUDuEQSSY9DyFbHkvVHLxQPPuqgkW6sL3QKt6Uhp',1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','YTo1OntzOjY6Il90b2tlbiI7czo0MDoiY0NwM1BqV250SnJPejdaVnFsdnZ1eUlXaTBXcFBaRjZJR29OZnpScSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjg6Imh0dHA6Ly9hYnNoZXIudGVzdC9kYXNoYm9hcmQiO3M6NToicm91dGUiO3M6OToiZGFzaGJvYXJkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6MTtzOjQ6ImF1dGgiO2E6MTp7czoyMToicGFzc3dvcmRfY29uZmlybWVkX2F0IjtpOjE3NjQ2MDM1NjQ7fX0=',1764603566),('QKSUk3d9JAPzl2fM7Uu5f6sb3HqTxoDbgLgqT4cR',1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','YTo2OntzOjY6Il90b2tlbiI7czo0MDoiR01veGNzTlh6U1cyYldoRUZ4VGhQOXlzbmZreGRqQU5nclY3UXBBTCI7czozOiJ1cmwiO2E6MDp7fXM6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjE4OiJodHRwOi8vYWJzaGVyLnRlc3QiO3M6NToicm91dGUiO3M6NzoibGFuZGluZyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7czo0OiJhdXRoIjthOjE6e3M6MjE6InBhc3N3b3JkX2NvbmZpcm1lZF9hdCI7aToxNzY0NjAzNjgzO319',1764604031);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `traffic`
--

DROP TABLE IF EXISTS `traffic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `traffic` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `road_id` bigint(20) unsigned DEFAULT NULL,
  `congestion` enum('low','medium','high') NOT NULL DEFAULT 'low',
  `severity` enum('info','warning','danger') NOT NULL DEFAULT 'info',
  `geometry` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`geometry`)),
  `detected_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `traffic_uuid_unique` (`uuid`),
  KEY `traffic_road_id_foreign` (`road_id`),
  KEY `traffic_congestion_detected_at_index` (`congestion`,`detected_at`),
  CONSTRAINT `traffic_road_id_foreign` FOREIGN KEY (`road_id`) REFERENCES `roads` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `traffic`
--

LOCK TABLES `traffic` WRITE;
/*!40000 ALTER TABLE `traffic` DISABLE KEYS */;
/*!40000 ALTER TABLE `traffic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `role` enum('user','government','investor','admin','super_admin') DEFAULT 'user',
  `avatar` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'ابراهيم صابر','user@user.com','user','https://ui-avatars.com/api/?name=User&background=3b82f6&color=fff&size=200',NULL,'0509876543',NULL,'$2y$12$hND/l0jed.a6HYLQu0iv3uRHuPWFtQzvRy1AqaDH/NcHYMQZ7NHMS','TwIIASggNoV7r5urP0LjD1yaT7y9dDKZ4ZM2ltwNNEZdj4DZDh0Qt93keWba','2025-11-29 09:22:33','2025-11-29 11:06:11'),(2,'مدير النظام','admin@admin.com','admin','https://ui-avatars.com/api/?name=Admin&background=764ba2&color=fff&size=200','إدارة النظام','920000004',NULL,'$2y$12$t5grUj8bJMJfdotm6TvaGOOftisgAWJDiai13wVzpeO6AJuVksqfe',NULL,'2025-11-29 09:22:33','2025-11-29 09:37:01'),(3,'المدير الرئيسي','super@admin.com','super_admin','https://ui-avatars.com/api/?name=Super+Admin&background=667eea&color=fff&size=200','الإدارة العامة','920000003',NULL,'$2y$12$fVL2qQ6ns5NK40De56..euNtaLlOhLddvR..D2BdKXGdZAyxDWra6','9MowvflHQHHGnYu2jptTYId8FVo6fSCmLTQkfXu7Qoi0ckK2JMORZLrDWFyc','2025-11-29 09:22:33','2025-11-29 09:37:01'),(4,'وزارة الشؤون البلدية','gov@gov.sa','government','https://ui-avatars.com/api/?name=Gov&background=3b82f6&color=fff&size=200','وزارة الشؤون البلدية والقروية','920000001',NULL,'$2y$12$1lFjGYPRyJbHVNrxJVaTBewSLLjoXO9LX3j9bmAPZy2UP0Rh6jNNm',NULL,'2025-11-29 09:37:01','2025-11-29 09:37:01'),(5,'شركة التطوير العقاري','investor@invest.com','investor','https://ui-avatars.com/api/?name=Investor&background=8b5cf6&color=fff&size=200','مجموعة التطوير العقاري','920000002',NULL,'$2y$12$Qs3zcjKiITR4iVwMGhBVouLtUVYtIRrL99WT54RpzYoe/5/8by5DW',NULL,'2025-11-29 09:37:01','2025-11-29 09:37:01');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-05 16:01:49
